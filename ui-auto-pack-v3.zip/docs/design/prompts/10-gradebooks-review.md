Thực hiện BƯỚC 10: Bảng điểm + lưới nhập điểm: gradebooks_screen.dart, gradebook_screen.dart, grade_deadlines_panel, excel_import_dialog. Làm đúng mục 0.1: nhãn trạng thái AppBadge "Đang nhập liệu" / "Đã khóa" thay cho nút chốt; hạn khóa chỉ hiện ở màn chi tiết khi MỌI cột nhập được đều có closesAt (dùng deadlineLabel), màn danh sách chỉ nhãn; đổi "Đã chốt"/"Đã chốt sổ" thành "Đã khóa" ở gradebook_screen.dart và gradebooks_screen.dart; cập nhật assertion tương ứng trong phase2_gradebooks_test.dart.
QUAN TRỌNG: trước khi sửa, xác nhận có test cho công thức trung bình (TX x1 tối đa 4 cột, Giữa kỳ x2, Cuối kỳ x3) và xếp loại (Giỏi >= 8.0, Khá >= 6.5, Đạt >= 5.0, còn lại Chưa đạt); nếu thiếu thì thêm. Không đổi logic tính toán, lưu điểm, phiên bản, xung đột, lịch sử sửa điểm; giữ key grade-<id>. Thêm 1 test mới cho nhãn trạng thái và hạn khóa (đủ lịch / thiếu lịch). Sau cùng grep lib/ để chắc chắn giao diện không gọi lock()/lockColumn(). Các chữ "chốt" nghĩa khác (điểm tổng kết, dashboard) giữ nguyên.

---
QUY TẮC CHUNG (đọc lại CLAUDE.md và docs/design/ui-migration-plan.md trước khi làm):
- Thiết kế tham chiếu: docs/design/Hệ thống quản lý điểm.html. Flutter client nằm ở apps/client_flutter; chạy flutter bằng `cd apps/client_flutter && flutter analyze` / `flutter test`.
- Chỉ sửa lớp hiển thị. Không đổi provider, repository, model, API, packages/api_client_dart, công thức tính điểm, quyền truy cập. Không đổi hay xóa route cũ; chỉ thêm route theo mục 4.1 của kế hoạch (bước 13).
- Giữ nguyên chuỗi tiếng Việt, ValueKey, loại widget, kích thước control (48), breakpoint (600/960/1024) mà test đang ghim (mục 3.3 của kế hoạch). Nếu BẮT BUỘC đổi một assertion của test thì chỉ sửa đúng assertion đó và nêu rõ trong tóm tắt.
- Không thêm package (không google_fonts, không shared_preferences). pubspec.yaml chỉ được thêm khai báo fonts. Không cài gì lên ổ C.
- Màu cứng (Color(0x..), Colors.xxx) trong file nào mình sửa thì gom về token/ThemeExtension để đúng ở dark mode (ThemeMode.system, không nút đổi, không lưu lựa chọn).
- KHÔNG thêm nút "Chốt bảng điểm", không gọi lock()/lockColumn() từ giao diện (mục 0.1 của kế hoạch). Giữ validate nhập điểm hiện có (bỏ qua bước 0,25 của prototype).
- Hạng mục prototype mà backend chưa hỗ trợ (mục 2 của kế hoạch): không làm giả, không tạo dữ liệu giả; ghi vào docs/design/open-questions.md.
- Cần quyết định mà tài liệu chưa nêu: chọn phương án giữ nguyên hành vi hiện tại, ghi vào docs/design/open-questions.md, KHÔNG hỏi lại.
- Cuối bước: chạy flutter analyze và flutter test (trong apps/client_flutter), sửa lỗi do mình gây ra, thêm một dòng vào docs/design/ui-progress.md (bước, file đã đổi, kết quả analyze/test), rồi in tóm tắt ngắn. Không commit (script sẽ commit).
