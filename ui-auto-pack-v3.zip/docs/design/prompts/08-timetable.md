Thực hiện BƯỚC 8: Thời khóa biểu: timetable_screen.dart, timetable_edit_dialog, timetable_filter. Lưới tiết 1-6 x Thứ 2-7 theo prototype. Giữ chức năng lọc/sửa/chuyển và các key ô lưới mà test ghim. Backend không có giờ bắt đầu từng tiết: dùng hằng cố định chỉ để hiển thị hoặc bỏ. HS không thấy phòng học. Test liên quan: timetable_admin_ux, timetable_layout, timetable_filter.

---
QUY TẮC CHUNG (đọc lại CLAUDE.md và docs/design/ui-migration-plan.md trước khi làm):
- Thiết kế tham chiếu: docs/design/Hệ thống quản lý điểm.html. Flutter client nằm ở apps/client_flutter; chạy flutter bằng `cd apps/client_flutter && flutter analyze` / `flutter test`.
- Chỉ sửa lớp hiển thị. Không đổi provider, repository, model, API, packages/api_client_dart, công thức tính điểm, quyền truy cập. Không đổi hay xóa route cũ; chỉ thêm route theo mục 4.1 của kế hoạch (bước 13).
- Giữ nguyên chuỗi tiếng Việt, ValueKey, loại widget, kích thước control (48), breakpoint (600/960/1024) mà test đang ghim (mục 3.3 của kế hoạch). Nếu BẮT BUỘC đổi một assertion của test thì chỉ sửa đúng assertion đó và nêu rõ trong tóm tắt.
- Không thêm package (không google_fonts, không shared_preferences). pubspec.yaml chỉ được thêm khai báo fonts. Không cài gì lên ổ C.
- Màu cứng (Color(0x..), Colors.xxx) trong file nào mình sửa thì gom về token/ThemeExtension để đúng ở dark mode (ThemeMode.system, không nút đổi, không lưu lựa chọn).
- KHÔNG thêm nút "Chốt bảng điểm", không gọi lock()/lockColumn() từ giao diện (mục 0.1 của kế hoạch). Giữ validate nhập điểm hiện có (bỏ qua bước 0,25 của prototype).
- Hạng mục prototype mà backend chưa hỗ trợ (mục 2 của kế hoạch): không làm giả, không tạo dữ liệu giả; ghi vào docs/design/open-questions.md.
- Cần quyết định mà tài liệu chưa nêu: chọn phương án giữ nguyên hành vi hiện tại, ghi vào docs/design/open-questions.md, KHÔNG hỏi lại.
- Cuối bước: chạy flutter analyze và flutter test (trong apps/client_flutter), sửa lỗi do mình gây ra, thêm một dòng vào docs/design/ui-progress.md (bước, file đã đổi, kết quả analyze/test), rồi in tóm tắt ngắn. Không commit (script sẽ commit).
