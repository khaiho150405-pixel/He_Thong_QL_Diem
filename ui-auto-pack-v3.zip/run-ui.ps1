﻿# Chạy tự động các bước UI từ đầu đến cuối bằng Claude CLI, tự sửa lỗi test và tự commit.
# Chạy ở thư mục gốc repo (He_Thong_QL_Diem):  .\run-ui.ps1
# Chạy từ bước N:  .\run-ui.ps1 -From 05
param([string]$From = "02", [int]$MaxFix = 2)
$ErrorActionPreference = "Continue"
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$root = (Get-Location).Path
$flutterDir = Join-Path $root "apps\client_flutter"
if (-not (Test-Path $flutterDir)) { Write-Host "Hãy chạy ở thư mục gốc He_Thong_QL_Diem." -ForegroundColor Red; exit 1 }
if (-not (Test-Path (Join-Path $flutterDir "assets\fonts\BeVietnamPro-Regular.ttf"))) { Write-Host "Thiếu font Be Vietnam Pro." -ForegroundColor Red; exit 1 }
if (-not (Test-Path -LiteralPath "docs\design\ui-migration-plan.md")) { Write-Host "Thiếu docs\design\ui-migration-plan.md" -ForegroundColor Red; exit 1 }
$branch = (git rev-parse --abbrev-ref HEAD).Trim()
if ($branch -in @("main","master")) { Write-Host "Đang ở nhánh $branch, hãy chuyển sang nhánh làm việc." -ForegroundColor Red; exit 1 }
$dirty = git status --porcelain
if ($dirty) { Write-Host "Còn thay đổi chưa commit. Hãy commit bước trước rồi chạy lại." -ForegroundColor Yellow; git status --short; exit 1 }

New-Item -ItemType Directory -Force docs\design\logs | Out-Null

$allowed = @("Read","Edit","Write","Glob","Grep","Bash(cd:*)","Bash(flutter analyze:*)","Bash(flutter test:*)","Bash(flutter build web:*)","Bash(dart format:*)","Bash(git diff:*)","Bash(git status:*)","Bash(git log:*)")

function Invoke-Claude([string]$msg, [string]$logFile) {
  claude -p $msg --permission-mode acceptEdits --allowedTools @allowed 2>&1 | Tee-Object -FilePath $logFile -Append
}

function Run-Checks {
  Push-Location $flutterDir
  try {
    $a = flutter analyze 2>&1 | Out-String
    $aok = ($LASTEXITCODE -eq 0)
    $t = ""; $tok = $false
    if ($aok) { $t = flutter test 2>&1 | Out-String; $tok = ($LASTEXITCODE -eq 0) }
  } finally { Pop-Location }
  if ($aok -and $tok) { return @{ ok = $true; log = "" } }
  $log = "=== flutter analyze ===`n$a`n=== flutter test ===`n$t"
  if ($log.Length -gt 20000) { $log = $log.Substring($log.Length - 20000) }
  return @{ ok = $false; log = $log }
}

$steps = Get-ChildItem docs\design\prompts\*.md | Sort-Object Name | Where-Object { $_.Name -ge "$From" }
foreach ($s in $steps) {
  $base = $s.BaseName
  $logFile = "docs\design\logs\$base.log"
  Write-Host "=== $($s.Name) ===" -ForegroundColor Cyan

  Invoke-Claude "Read the file docs/design/prompts/$($s.Name) and carry out the instructions in it exactly. Follow CLAUDE.md. Do not commit." $logFile

  $r = Run-Checks
  $try = 0
  while (-not $r.ok -and $try -lt $MaxFix) {
    $try++
    Write-Host "Test/analyze lỗi, nhờ Claude sửa (lần $try/$MaxFix)..." -ForegroundColor Yellow
    $failFile = "docs\design\logs\$base-fail$try.log"
    Set-Content -Path $failFile -Value $r.log -Encoding UTF8
    Invoke-Claude "Read the file $failFile. It contains flutter analyze / flutter test failures caused by the step in docs/design/prompts/$($s.Name). Fix the code so analyze and tests pass, without changing business logic, routes, or API, and without weakening tests beyond what CLAUDE.md allows. Do not commit." $logFile
    $r = Run-Checks
  }
  if (-not $r.ok) {
    Write-Host "Bước $base vẫn lỗi sau $MaxFix lần sửa. Dừng, chưa commit. Xem docs\design\logs\$base-fail*.log" -ForegroundColor Red
    break
  }

  git add -A
  git commit -m "ui: $base" | Out-Null
  Write-Host "Đã commit bước $base" -ForegroundColor Green
}
Write-Host "Xong. Xem docs\design\open-questions.md, ui-progress.md và logs." -ForegroundColor Green
