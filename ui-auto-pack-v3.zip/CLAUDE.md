# CLAUDE.md

Đọc `AGENTS.md` (kim chỉ nam dự án: nghiệp vụ, kiến trúc, phân quyền) trước khi sửa code.
@AGENTS.md

## Dự án
- Hệ thống quản lý điểm. Flutter client ở `apps/client_flutter` (Material 3, Riverpod, GoRouter). Backend NestJS ở `apps/api`, dịch vụ nhận dạng ở `apps/recognition-service`, client API sinh ra ở `packages/api_client_dart`.
- Lệnh Flutter luôn chạy trong `apps/client_flutter`: `flutter analyze`, `flutter test`. Mọi thay đổi code phải qua hai lệnh này và báo kết quả.
- Trả lời và viết chú thích bằng tiếng Việt.

## Quy tắc thiết kế lại UI
- Thiết kế tham chiếu: `docs/design/Hệ thống quản lý điểm.html` (token, bố cục, component). Kế hoạch từng bước và các quyết định đã chốt: `docs/design/ui-migration-plan.md` (đọc mục 0 đến 4 trước khi làm).
- Chỉ sửa lớp hiển thị (widget, theme, layout). KHÔNG đổi provider, repository, model, API, `packages/api_client_dart`, quyền truy cập, công thức tính điểm, validate nhập điểm.
- KHÔNG đổi hay xóa route cũ. Chỉ được THÊM route mới theo mục 4.1 của kế hoạch, guard phân quyền giống màn tương ứng.
- Giữ nguyên chuỗi tiếng Việt, `ValueKey`, loại widget, kích thước control 48, breakpoint 600/960/1024 mà test đang ghim (mục 3.3 của kế hoạch). Nếu bắt buộc đổi một assertion của test thì chỉ sửa đúng assertion đó và nêu rõ trong tóm tắt.
- Màu và kiểu chữ lấy từ token (`context.tokens` trong `lib/app/design_tokens.dart`, `AppRadius`, `AppSpacing`, theme). Không viết màu cứng (`Color(0x..)`, `Colors.xxx`) trong file mình sửa; dark mode theo `ThemeMode.system`, không nút đổi, không lưu lựa chọn.
- Font Be Vietnam Pro đóng gói trong `assets/fonts`. Không thêm package nào (không `google_fonts`, không `shared_preferences`); `pubspec.yaml` chỉ được thêm khai báo fonts. Không cài gì lên ổ C.
- KHÔNG thêm nút "Chốt bảng điểm" và không gọi `lock()` / `lockColumn()` từ giao diện; dùng nhãn trạng thái "Đang nhập liệu" / "Đã khóa" (mục 0.1 của kế hoạch).
- Hạng mục trong thiết kế mà backend chưa hỗ trợ (mục 2 của kế hoạch): không làm giả chức năng, không tạo dữ liệu giả; ghi vào `docs/design/open-questions.md`.
- Khi cần quyết định mà tài liệu chưa nêu: chọn phương án giữ nguyên hành vi hiện tại, ghi vào `docs/design/open-questions.md`, không hỏi lại.
- Sau mỗi bước: thêm một dòng vào `docs/design/ui-progress.md` (bước, file đã đổi, kết quả analyze/test). Không tự commit trừ khi được yêu cầu.
