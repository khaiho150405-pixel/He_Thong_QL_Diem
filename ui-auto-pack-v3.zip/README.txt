GÓI v3 (chạy tự động, bước 1 đã làm xong)
1. Giải nén vào F:\HK1_Nam04\KLCN\He_Thong_QL_Diem. Cho phép ghi đè CLAUDE.md; docs\design\prompts và run-ui.ps1 là file mới.
2. Commit bước 1 và các file vừa chép:  git add -A ; git commit -m "ui: buoc 1 + chuan bi"
3. Chạy:  Set-ExecutionPolicy -Scope Process Bypass ; .\run-ui.ps1
   (chạy từ bước khác:  .\run-ui.ps1 -From 05)
Script chạy các bước 02 đến 15, mỗi bước: Claude làm, chạy analyze+test, lỗi thì nhờ Claude sửa tối đa 2 lần, đạt thì tự commit; vẫn lỗi thì dừng không commit.
